import { Routes } from '@angular/router';
import { Producto } from './components/producto/producto';
import { Checkout } from './components/checkout/checkout';
import { Aboutus } from './components/aboutus/aboutus';

export const routes: Routes = [
  { path: 'producto/:id', component: Producto },
  { path: 'checkout', component: Checkout },
  { path: 'aboutus', component: Aboutus }
];
