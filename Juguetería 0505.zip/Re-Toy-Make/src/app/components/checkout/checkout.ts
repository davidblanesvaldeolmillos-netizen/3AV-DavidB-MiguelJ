import { Component } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './checkout.html',
  styleUrl: './checkout.css',
})
export class Checkout {
  checkoutForm = new FormGroup({
    paymentMethod: new FormControl('', Validators.required),
    shipping: new FormGroup({
      nombre: new FormControl('', Validators.required),
      apellidos: new FormControl('', Validators.required),
      direccion: new FormControl('', Validators.required),
      ciudad: new FormControl('', Validators.required),
      codigoPostal: new FormControl('', [Validators.required, Validators.pattern(/^\d{5}$/)]),
      telefono: new FormControl('', [Validators.required, Validators.pattern(/^\d{9}$/)]),
      email: new FormControl('', [Validators.required, Validators.email]),
    }),
  });

  onSubmit() {
    if (this.checkoutForm.valid) {
      console.log(this.checkoutForm.value);
      // Handle form submission
    }
  }
}