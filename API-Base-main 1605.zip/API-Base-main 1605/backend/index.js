const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/api/saludo', (req, res) => {
  res.json({ mensaje: 'Hola desde Node!' });
});

app.listen(3000, () => {
  console.log('Servidor Node corriendo en http://localhost:3000');
});
