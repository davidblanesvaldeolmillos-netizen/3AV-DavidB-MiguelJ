import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {SidebarComponent} from './layout/sidebar/sidebar.component';
import {NavbarComponent} from './layout/navbar/navbar.component';
import { ApiService } from './servicios/api.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, SidebarComponent, NavbarComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'API-Base';

  constructor(private api: ApiService) { }

  ngOnInit() {
    this.api.getSaludo().then(res => console.log(res));
  }
}
